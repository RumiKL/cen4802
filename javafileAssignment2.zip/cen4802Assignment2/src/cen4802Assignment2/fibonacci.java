package cen4802Assignment2;

public class fibonacci {
	
	public static int fib(int n) {
		
		if(n<=1)
			return n;
		else 
		
		return fib(n-1) + fib(n-2);
	}
	public static void main(String[] args) {
		int n = 9;
		if(n<0)
			System.out.println("Fibonacchi number is not defined");
		else
			System.out.println("Fibonacchi 10th number is " + fib(n));
	}

}
