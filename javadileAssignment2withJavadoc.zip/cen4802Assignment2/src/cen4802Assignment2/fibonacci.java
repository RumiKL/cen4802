package cen4802Assignment2;

/** Fibonacci program to find Nth number 
 * @author Rumi Lewandowski
 * @param n any integer value
 * @return n if n<=1, otherwise fib(n-1) + fib(n-2)
*/

public class fibonacci {
	
	public static int fib(int n) {
		//base case
		if(n<=1)
			return n;
		//recursive case
		else 
		
		return fib(n-1) + fib(n-2);
	}
	public static void main(String[] args) {
		int n = 9;//n starts from 0, therefore, n=9 is to find the 10th number  
		if(n<0) 
			System.out.println("Fibonacchi number is not defined");
		else//display the 10th number
			System.out.println("Fibonacchi 10th number is " + fib(n));
	}

}
